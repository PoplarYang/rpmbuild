#include <stdio.h>
int main(void) {
    printf("Hello World, I'm DavidWei!\n");
    return 0;
}
